- 함수의 일부 이름 변경이 필요할시에 serverless.yml의 "# name 지정" 부분을 수정하면 됩니다.

- 이메일 구독 설정 후에 별도로 메일 인증 url을 확인해야 정상등록이 됩니다.

serverless plugin install -n serverless-lift