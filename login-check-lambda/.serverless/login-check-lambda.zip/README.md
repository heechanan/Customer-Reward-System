1. npm install
2. sls deploy
3. sls dynamodb:seed